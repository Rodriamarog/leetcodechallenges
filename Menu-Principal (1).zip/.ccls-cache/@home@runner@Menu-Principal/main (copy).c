#include <stdio.h>
#include <stdlib.h>  
#include <time.h>
#include <string.h>

int main(void) {
  char centinela = 'p';
  int juego = 0;
  int seguir = 0;
  int peso = 0;
  int planeta = 0;
  int score = 0;
  int respuesta = 0;
  int fichas = 1000;
  int player_sum = 0;
  int cpu_sum = 0;
  // Variables  Black Jack
  //Probabilidades de Blackjack y carta 10 para Jugador
  int TenCardOdds = rand()%100+1;
  int BlackjackOdds = rand()%100+1;
  
  //Probabilidades de Blackjack y carta 10 para Dealer
  int TenCardOdds2 = rand()%100+1;
  int BlackjackOdds2 = rand()%100+1;
  
  //Cartas random menores a 10 para Jugador
  int random1 = rand()%10+1;
  int random2 = rand()%10+1;
  
  //Cartas random menores a 10 para Dealer
  int random3 = rand()%10+1;
  int random4 = rand()%10+1;
  int apuesta = 0;
  int otraCarta = 0;
  int playAgain = 0;

  srand(time(NULL));
  MenuPrincipal:
  fichas = 1000;
  system("clear");
  //Menu principal//
  printf("\t\t\t\t\t>>> MENU PRINCIPAL <<<\n\n\n");
  puts("1. Piedra Papel o Tijera\n");
  puts("2. Ruleta Rusa\n");
  puts("3. Calculadora de peso en Planetas\n");
  puts("4. Juego de Trivia\n");
  puts("5. Blackjack\n");
  printf("Escribe aqui el numero del juego >>> ");
  scanf("%i", &juego);
  system("clear");
  switch(juego)
    {
    case 1:
  inicioPPT:
  srand(time(NULL));
  int random = rand(); 
  int selecc_cpu = random%3+1;
  int selecc_jugador = 0;
  
  
  system("clear");
  //Pedimos la seleccion del jugador
  printf("Elige piedra papel o tijeras con los siguientes numeros:\n");
  puts("1.Piedra  2.Papel  3.Tijeras");
  scanf("%i", &selecc_jugador);
  puts(" ");

  //Si no nos da un numero valido, volvemos al inicio con goto
  if (selecc_jugador != 1 && selecc_jugador != 2 && selecc_jugador != 3){
    puts("No diste un numero valido, los numeros validos solo son 1, 2 y 3, vuelve a intentarlo.\n");
    goto inicioPPT;
  }
  
  //Imprime la seleccion del CPU
  if (selecc_cpu == 1)
  {
    puts("La computadora selecciono Piedra");
    puts("    _______");
    puts("---'   ____)");
    puts("      (_____)");
    puts("      (_____)");
    puts("      (____)");
    puts("---.__(___)");
  }
  else if (selecc_cpu == 2)
  {
    puts("La computadora selecciono Papel");
    puts("     _______");
    puts("---'    ____)____");
    puts("           ______)");
    puts("          _______)");
    puts("         _______)");
    puts("---.__________)");
  }
  else if (selecc_cpu == 3)
  {
    puts("La computadora selecciono Tijeras");
     puts( "  _       ,/'");
    puts("(_).  ,/'");
    puts(" _  ::");
    puts("(_)'  `\.");
    puts("         `\." );
  }
  
  //Imprimie la seleccion del Jugador
  if (selecc_jugador == 1)
  {
    puts("Tu seleccionaste Piedra\n");
    puts("    _______");
    puts("---'   ____)");
    puts("      (_____)");
    puts("      (_____)");
    puts("      (____)");
    puts("---.__(___)");
  }
  else if (selecc_jugador == 2)
  {
    puts("Tu seleccionaste Papel\n");
    puts("     _______");
    puts("---'    ____)____");
    puts("           ______)");
    puts("          _______)");
    puts("         _______)");
    puts("---.__________)");
  }
  else if (selecc_jugador == 3)
  {
    puts("Tu seleccionaste Tijeras\n");
     puts( "  _       ,/'");
    puts("(_).  ,/'");
    puts(" _  ::");
    puts("(_)'  `\.");
    puts("         `\." );
  }

  //Lo que sucede si la compu y el jugador eligen lo mismo
  if (selecc_cpu == selecc_jugador)
  {
    puts("Es un empate!");
  }

  //Los casos posibles cuando la computadora elige piedra
  else if (selecc_cpu == 1 && selecc_jugador == 2)
  {
    puts("Ganaste!");
  }
  else if (selecc_cpu == 1 && selecc_jugador == 3)
  {
    puts("Gano la computadora!");
  }

  //Los casos posibles cuando la computadora elige papel
  else if (selecc_cpu == 2 && selecc_jugador == 1)
  {
    puts("Gano la computadora!");
  }
  else if (selecc_cpu == 2 && selecc_jugador == 3)
  {
    puts("Ganaste!");
  }

  //Los casos posibles cuando la computadora elige Tijeras
  else if (selecc_cpu == 3 && selecc_jugador == 1)
  {
    puts("Ganaste!");
  }
  else if (selecc_cpu == 3 && selecc_jugador == 2)
  {
    puts("Gano la computadora!");
  }
  ifPPT:
  puts("Para jugar otra vez, presiona el 1\nPara ir al menu principal, presiona el 2");
  scanf("%i", &seguir);
  
  if (seguir == 1)
    goto inicioPPT;
  else if (seguir == 2)
    goto MenuPrincipal;
  else{
    puts("Input no valido");
    goto ifPPT;
      }      
  break;  
      
    case 2:
      inicioRULETA:
      system("clear");
srand(time(NULL));
  int random2 = rand(); 
  
  int numeros[6] = {1,2,3,4,5,6};
  int jugadores[6] = {1,2,3,4,5,6};
  int jug_num[6] = {0,0,0,0,0,0};
  
  for(int i = 0; i <= 5; i++)
  {
    printf("Jugador #%i, elige un numero del 1-6. Los numeros disponibles son \n", jugadores[i]);
    for(int j = 0; j < 6; j++){
      if(numeros[j] != jug_num[0]&&numeros[j] != jug_num[1]&&numeros[j]         != jug_num[2]&&numeros[j] != jug_num[3]&&numeros[j] !=                   jug_num[4]&&numeros[j] != jug_num[5]){
        printf("%i ", numeros[j]);
      }
    }
    scanf("%i", &jug_num[i]);
  }
  int bala = random2%6+1;
  printf("\nLa bala que disparo fue la {%i}\n", bala);
       puts("    /  ");
    puts("   /                                 /> ");
    puts("   \__+_____________________/\ /\___/ /| ");
    puts("  ()______________________      / /|/\*  ");
    puts("            /0 0  ---- |----    /---\*  ");
    puts("           |0 o 0 ----|| - \ --|      \*   ");
    puts("           \ 0_0/____/ |    |  |\      \*  ");
    puts("                        \__/__/  |      \*  ");
    puts( "Bang! Bang!                      |       \* ");
    puts("                                  |         \* ");
    puts("                                  |__________|  ");
  for (int k = 0; k <= 5; k++){
    if (jug_num[k] == bala){
      printf("\nEl jugador que perdio fue el %i", k+1);
      
    }
  }
    puts("\nPara jugar otra vez, presiona el 1\nPara ir al menu principal, presiona el 2");
  scanf("%i", &seguir);
  ifRULETA:
  if (seguir == 1)
    goto inicioRULETA;
  else if (seguir == 2)
    goto MenuPrincipal;
  else{
    puts("Input no valido");
    goto ifRULETA;
      }

    break;
  
    case 3:
      inicioPlanetas:
      system("clear");
      puts("Dime tu peso en kg: ");
      scanf("%i", &peso);
      puts("Elige un planeta para calcluar tu peso en kilogramos: ");
      puts("1. Luna\n2. Mercurio\n3. Venus\n4. Marte\n5. Jupiter\n6. Saturno\n7. Urano\n8. Neptuno");
      puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣤⣶⣾⠿⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⠀⠀⠀⠈⠛⢦⡀⠀");
puts("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⠶⢛⣩⠶⠛⠉⠀⠀⠀⣀⣤⡴⠶⠚⠛⠛⠛⠉⠛⠛⠛⢶⡟⠉⢻⡄⠀⠀⠀⠈⢻⡄");
puts("⠀⠀⠀⠀⠀⠀⠀⣠⡴⠟⢉⣠⠶⠋⠁⠀⠀⣠⡴⠞⠋⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠷⡤⠾⣇⠀⠀⠀⠀⠀⣿");
puts("⠀⠀⠀⠀⣠⡴⠛⠁⣀⡴⠛⠁⠀⢀⣠⠶⠛⠁⠀⠀⠀⣀⣠⡤⠶⠒⠛⠛⠛⠛⠛⠶⣤⡀⠀⠀⠀⢹⡆⠀⠀⠀⠀⢸");
puts("⠀⢀⣴⠟⠁⠀⣠⡾⠋⠀⠀⢀⡴⠛⠁⠀⢰⠞⠳⡶⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣷⠀⠀⠀⢈⡇⠀⠀⠀⠀⣾");
puts("⢴⠟⠁⠀⢀⡼⠋⠀⠀⢀⡴⠋⠀⠀⠀⣠⡾⠷⠶⠇⢀⣠⣤⠶⠖⠲⢶⣄⠀⠀⠀⠀⠀⡿⠀⠀⠀⢸⡇⠀⠀⠀⢰⡏");
puts("⠀⠀⠀⣰⠟⠀⠀⠀⣴⠏⠀⠀⠀⣠⠞⠉⠀⠀⣠⡶⠋⠁⠀⠀⠀⠀⢀⡿⠀⠀⠀⠀⣼⠃⠀⠀⢀⡟⠂⠀⠀⢠⡟⠀");
puts("⠀⢀⣼⠋⠀⠀⢀⡾⠁⠀⠀⢠⡞⠁⠀⠀⢠⡾⠁⠀⠀⠀⠀⣀⣀⣠⡾⠁⠀⠀⣠⡾⠁⠀⠀⢠⡞⠁⠀⠀⣰⠟⠀⠀");
puts("⠀⣾⠃⠀⢠⡟⠛⣷⠂⠀⢠⡟⠀⠀⠀⠀⢾⡀⠀⠀⠀⠀⣸⣏⣹⡏⠀⠀⣠⡾⠋⠀⠀⢀⣴⠏⠀⠀⢀⡼⠋⠀⠀⠀");
puts("⣸⠇⠀⠀⠈⢻⡶⠛⠀⠀⣿⠀⠀⠀⠀⠀⠈⠛⠲⠖⠚⠋⠉⠉⠉⣀⣤⠞⠋⠀⠀⢀⣴⠟⠁⠀⠀⣰⠟⠁⠀⣴⠆⠀");
puts("⣿⠀⠀⠀⠀⢸⡇⠀⠀⠀⢻⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⠶⠛⠉⣀⣀⡀⣀⡴⠟⠁⠀⢀⣤⠞⠁⢀⣴⠟⠁⠀⠀");
puts("⣿⠀⠀⠀⠀⠘⣧⠀⠀⠀⠀⠙⠳⠶⠤⣤⠤⠶⠶⠚⠋⠉⠀⠀⠀⡟⠉⠈⢻⡏⠀⠀⣀⡴⠛⠁⣠⡶⠋⠁⠀⠀⠀⠀");
puts("⢻⡀⠀⠀⠀⠀⠘⢷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⠶⠻⢦⣤⠟⣀⣤⠞⢋⣠⡴⠛⠁⠀⠀⠀⠀⠀⠀⠀");
puts("⠈⢿⣄⠀⠀⠀⠀⠀⠈⠛⠳⠶⠤⠤⠤⠤⠤⠴⠶⠒⠛⠉⠁⠀⠀⢀⣠⡴⣞⣋⣤⠶⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
puts("⠀⠀⠙⢷⡶⠛⠳⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣴⣾⠿⠿⠛⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
puts("⠀⠀⠀⠘⣧⡀⣀⣿⠦⣤⣤⣤⣤⣤⣤⠤⠶⠶⠞⠛⠋⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
puts("⠀⠀⠀⠀⠈⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");
      scanf("%i", &planeta);
      switch (planeta)
        {
          case 1:
            printf("%.2f", peso*0.165);
            puts("\t🌚");
            goto ifPlanetas;
          break;
          case 2:
            printf("%.2f", peso*0.38);
            goto ifPlanetas;
          break;
          case 3:
            printf("%.2f", peso*0.91);
            goto ifPlanetas;
          break;
          case 4:
            printf("%.2f", peso*0.38);
            goto ifPlanetas;
          break;
          case 5:
            printf("%.2f", peso*2.479);
            goto ifPlanetas;
          break;
          case 6:
            printf("%.2f\n", peso*1.08);
    puts("          ,MMM8&&&.");
    puts("     _...MMMMM88&&&&..._");
    puts("  .::'''MMMMM88&&&&&&'''::.");
    puts(" ::     MMMMM88&&&&&&     ::");
    puts(" '::....MMMMM88&&&&&&....::'");
    puts("    `''''MMMMM88&&&&''''`");
    puts("          'MMM8&&&'");
            goto ifPlanetas;
          break;
          case 7:
            printf("%.2f", peso*0.86);
            goto ifPlanetas;
          break;
          case 8:
            printf("%.2f", peso*1.1);
            goto ifPlanetas;
          break;
          default:
            goto ifPlanetas;
          break;

          ifPlanetas:
           puts("\n\nQuieres explorar otro planeta o volver al menu principal?\n1) Explorar otro planeta\n2) Menu Principal");
             scanf("%i", &seguir);
          if (seguir == 1)
            goto inicioPlanetas;
          else if (seguir == 2)
            goto MenuPrincipal;
          else
          {
            puts("Valor invalido");
            goto ifPlanetas;
          }
        }
     break;
      
    case 4:
      inicioTrivia:
      system("clear");
      printf("Bienvenido a el quiz mas importante de tu vida!!\nVan a ser 10 preguntas, y 3 respuestas posibles por pregunta. \nTu puntuacion sera del 0-10. Elige la respuesta correcta. Suerte!\n\n");
      puts("(╭ರ_ ⊙ )\n");
      printf("Pregunta 1.\tQuien era el Dios Romano de la guerra?\n1) Ares\n2) Jupiter\n3) Marte\n");//Marte
  scanf("%i", &respuesta);
  system("clear");
  if (respuesta == 3)
  {
    printf("Respuesta correcta!\n\n");
    score++;
  }
       else
  {
    puts("Respuesta incorrecta\n\n");
  }
  
  printf("Pregunta 2. \n Quien escribio la Odisea?\n1) Aristoteles \n2) Platon \n3) Homero \n");
  scanf("%i", &respuesta);
  system("clear");
  if (respuesta == 3)
  {
    puts("Respuesta correcta!\n\n");
    score++;
  }
  else
  {
    puts("Respuesta incorrecta\n\n");
  }
      printf("Pregunta 3. \n Cuantos huesos tiene el cuerpo humano adulto?\n1) 207 \n2) 300 \n3) 206\n ");
  scanf("%i", &respuesta);
  system("clear");
  if (respuesta == 3)
  {
    puts("Respuesta correcta!\n\n");
    score++;
  }
  else
  {
    puts("Respuesta incorrecta\n\n");
  }
      printf("Pregunta 4. \n Cual es el animal mas rapido del mundo?\n1) Jaguar \n2) Guepardo \n3) Cheetah\n ");
  scanf("%i", &respuesta);
  system("clear");
  if (respuesta == 2)
  {
    puts("Respuesta correcta!\n\n");
    score++;
  }
  else
  {
    puts("Respuesta incorrecta\n\n");
  }
  

  printf("Pregunta 5 \n Quien pinto la ultima cena?\n1) Leonardo DaVinci \n2) Leonardo Dicaprio \n3) Michelangelo\n ");
  scanf("%i", &respuesta);
  system("clear");
  if (respuesta == 1)
  {
    puts("Respuesta correcta!\n\n");
    score++;
  }
  else
  {
    puts("Respuesta incorrecta\n\n");
  }
        printf("Pregunta 6. \n Cual es el libro mas vendido de la historia?\n1) Romeo y Julieta \n2) La Biblia \n3) Don Quijote de la Mancha\n ");
  scanf("%i", &respuesta);
  system("clear");
  if (respuesta == 2)
  {
    puts("Respuesta correcta!\n\n");
    score++;
  }
  else
  {
    puts("Respuesta incorrecta\n\n");
  }


  printf("Pregunta 7. \n Cuantos elemntos hay en la tabla periodica?\n1) 120 \n2) 118 \n3) 115\n ");
  scanf("%i", &respuesta);
    system("clear");
  if (respuesta == 2)
  {
    puts("Respuesta correcta!\n\n");
    score++;
  }
  else
  {
    puts("Respuesta incorrecta\n\n");
  }


  printf("Pregunta 8. \n En que pais se uso la primer bomba atomica?\n1)Alemania \n2) Rusia \n3) Japon \n");
  scanf("%i", &respuesta);
  system("clear");
  if (respuesta == 3)
  {
    puts("Respuesta correcta!\n\n");
    score++;
  }
  else
  {
    puts("Respuesta incorrecta\n\n");
  }
  

  printf("Pregunta 9. \n Cuantas veces ha estado el hombre en la luna?\n1) 1 vez \n2) 6 veces \n3) 3 veces \n");
  scanf("%i", &respuesta);
  system("clear");
  if (respuesta == 2)
  {
    puts("Respuesta correcta!\n\n");
    score++;
  }
  else
  {
    puts("Respuesta incorrecta\n\n");
  }
  printf("Pregunta 10. \n Cual es el rio mas largo del planeta?\n1) El Amazonas \n2) El Nilo \n3) El Bravo \n");
  scanf("%i", &respuesta);
  system("clear");
  if (respuesta == 1)
  {
    puts("Respuesta correcta!\n\n");
    score++;
  }
  else
  {
    puts("Respuesta incorrecta\n\n");
  }
    printf("Tu puntuacion final es de %i\n", score);
    ifTrivia:
  puts("Quieres jugar otra vez a Trivia o ir al menu principal?\n1) Jugar Otra Vez\n2) Menu Principal");
      scanf("%i", &seguir);
      if (seguir == 1)
        goto inicioTrivia;
      else if (seguir == 2)
          goto MenuPrincipal;
      else
      {
        puts("Valor invalido");
        goto ifTrivia;
      }
      
     break;

  
    case 5:
  //Aqui se reinicia todo excepto las fichas
  apuestaInicial:
  system("clear");
      puts("               _     _            _    _            _ ");
    puts("             | |   | |          | |  (_)          | | ");
    puts("             | |__ | | __ _  ___| | ___  __ _  ___| | __");
    puts("             | '_ \* | |/ _` |/ __| | / / |/ _` |/ __| |/ /  ");
    puts("             | |_) | | (_| | (__|   < | | (_| | (__|    <  ");
    puts("             |_.__/|_| *\__,_|\___|_| \_ \*  |\__,_|\___|_| \_\\  ");
    puts("                                      _/ | ");
    puts("                                     |__/ " );

  
  if(fichas <= 0)
  {
    printf("\nYa no tienes fichas. No puedes jugar otra mano.\nPresiona # para volver al menu: "); 
    while (centinela != '#')
    {
      scanf("%c", &centinela);  
    }
    goto MenuPrincipal;
  }
  
  
  player_sum = 0;
  cpu_sum = 0;
  TenCardOdds = rand()%100+1;
  BlackjackOdds = rand()%100+1;
  random1 = rand()%10+1;
  random2 = rand()%10+1;
  TenCardOdds2 = rand()%100+1;
  BlackjackOdds2 = rand()%100+1;
  random3 = rand()%10+1;
  random4 = rand()%10+1;
  

  //Candado si usuario intenta apostar mas de las fichas que tiene
  printf("\nBienvenido a Blackjack! Tienes %i fichas, cuantas quieres apostar?\n", fichas);
  scanf("%i", &apuesta);
  if(apuesta > fichas)
  {
    puts("No tienes suficientes fichas, vuelve a intentarlo.");
    goto apuestaInicial;
  }

  //Probabilidades de Blackjack
  if (BlackjackOdds <= 8)
  {
    puts("Tus cartas iniciales fueron 10 y A, FELICIDADES CONSEGUISTE BLACKJACK!!!\n");
    fichas += apuesta;
    printf("Tu nuevo total de fichas es %i\n", fichas);
   
    puts("Presiona 1 para pedir jugar otra vez. \tPresiona 2 para volver al menu principal");
    
      while (playAgain != 1 && playAgain != 2)
    {
      scanf("%i", &playAgain);
      if (playAgain == 1)
      {
        goto apuestaInicial;
      }
      else if (playAgain == 2)
    {
      goto MenuPrincipal;
    }
  }
    }

  //Probabilidades de obtener carta con valor de 10
  else if (TenCardOdds <= 30)
  {
    printf("Tus cartas iniciales fueron %i y %i\n", 10, random1);
    player_sum += 10 + random1;
    while (player_sum <= 21)
    {
      printf("La suma es %i\n", player_sum);
      
      OtraCarta1:
      puts("Quieres otra carta? Escribe 1 para Sí y 2 para No");
      scanf("%i", &otraCarta);
      
      if (otraCarta != 1 && otraCarta != 2)
      {
        puts("No me diste un numero valido, es 1 para Si y 2 para No, vuelve a intentarlo.");
        goto OtraCarta1;
      }
        
      else if (otraCarta == 1)
      {
        player_sum += rand()%10+1;
      }

      else
      {
        break;  
      }
    }
    
    if(player_sum <= 21)
    {
      printf("Tu mano final es %i, veamos que consigue el Dealer, suerte!\n", player_sum);
    }

    else
    {
      printf("Tu mano final es %i, te pasaste de 21, pierdes tu apuesta!\n", player_sum);
      fichas -= apuesta;
      printf("Tu nuevo total de fichas es %i\n", fichas);
     
      puts("Presiona 1 para jugar otra vez. \tPresiona 2 para volver al menu principal");
    while (playAgain != 1 && playAgain != 2)
    {
      scanf("%i", &playAgain);
      if (playAgain == 1)
      {
        goto apuestaInicial;
      }
      else if (playAgain == 2)
    {
      goto MenuPrincipal;
    }
    }
    }
  }

  //Secuencia normal si no hubo Blackjack ni carta con valor 10
  else 
  {
    printf("Tus cartas iniciales fueron %i y %i\n", random1,random2);
    player_sum += random1 + random2;
    while (player_sum <= 21)
    {
      printf("La suma es %i\n", player_sum);
      
      OtraCarta2:
      puts("Quieres otra carta? Escribe 1 para Sí y 2 para No");
      scanf("%i", &otraCarta);
      
      if (otraCarta != 1 && otraCarta != 2)
      {
        puts("No me diste un numero valido, es 1 para Si y 2 para No, vuelve a intentarlo.");
        goto OtraCarta2;
      }
        
      else if (otraCarta == 1)
      {
        player_sum += rand()%10+1;
      }

      else
      {
        break;  
      }
    }
    
    if(player_sum <= 21)
    {
      printf("Tu mano final es %i, veamos que consigue el Dealer, suerte!\n", player_sum);
    }

    else
    {
      printf("Tu mano final es %i, te pasaste de 21, pierdes tu apuesta!\n", player_sum);
      fichas -= apuesta;
      printf("Tu nuevo total de fichas es %i\n", fichas);
     
      puts("Presiona 1 para jugar otra vez. \tPresiona 2 para volver al menu principal");
      while (playAgain != 1 && playAgain != 2)
    {
      scanf("%i", &playAgain);
      if (playAgain == 1)
      {
        goto apuestaInicial;
      }
      else if (playAgain == 2)
    {
      goto MenuPrincipal;
    }
    }
  }

  //Secuencia si el jugador no pierde. Se inicia la mano del Dealer
  puts("Veamos las cartas del Dealer");

  if (BlackjackOdds2 <= 8)
  {
    puts("Las cartas fueron 10 y A. El dealer obtuvo Blackjack!! Pierdes tu apuesta");
    fichas -= apuesta;
    printf("Tu nuevo total de fichas es %i\n", fichas);
   
    puts("Presiona 1 para jugar otra vez. \tPresiona 2 para volver al menu principal");
    while (playAgain != 1 && playAgain != 2)
    {
      scanf("%i", &playAgain);
      if (playAgain == 1)
      {
        goto apuestaInicial;
      }
      else if (playAgain == 2)
    {
      goto MenuPrincipal;
    }
  }
    }
  else if (TenCardOdds2 <= 30)
  {
    printf("Las cartas iniciales del dealer fueron %i y %i\n", 10, random3);
    cpu_sum += 10 + random3;
    
    while (cpu_sum < 17)
      {
        puts("Como el total del dealer es menor a 17, el dealer tiene que pedir una carta mas");
        cpu_sum += rand()%10+1;
        printf("El nuevo total del dealer es %i", cpu_sum);
      }
    
    if (cpu_sum > 21)
    {
      puts("El dealer se paso de 21, GANASTE!!");
      fichas += apuesta;
      printf("Tu nuevo total de fichas es %i\n", fichas);
    
      puts("Presiona 1 para pedir otra mano de cartas. \tPresiona 2 para volver al menu principal");
      scanf("%i", &playAgain);
      if (playAgain == 1)
      {
        goto apuestaInicial;
      }
      else if (playAgain == 2)
    {
      goto MenuPrincipal;
    }
    }

    else if (cpu_sum <= 21)
    {
      printf("  La mano final del dealer es %i\n", cpu_sum);
      if (player_sum > cpu_sum)
      {
        puts("Tu mano es mayor, Ganaste!!");
        fichas += apuesta;
        printf("Tu nuevo total de fichas es %i", fichas);
       
        puts("Presiona 1 para pedir otra mano de cartas. \tPresiona 2 para volver al menu principal");
        scanf("%i", &playAgain);
        if (playAgain == 1)
        {
          goto apuestaInicial;
        }
        else if (playAgain == 2)
    {
      goto MenuPrincipal;
    }
      }

      else if (player_sum < cpu_sum)
      {
        puts("Tu mano es menor, Perdiste!!");
        fichas -= apuesta;
        printf("Tu nuevo total de fichas es %i", fichas);
       
        puts("Presiona 1 para pedir otra mano de cartas. \tPresiona 2 para volver al menu principal");
        scanf("%i", &playAgain);
        if (playAgain == 1)
        {
          goto apuestaInicial;
        }
        else if (playAgain == 2)
    {
      goto MenuPrincipal;
    }
      }

      else
      {
        puts("Es un empate, no pierdes ni ganas fichas");
        puts("Presiona 1 para pedir otra mano de cartas. \tPresiona 2 para volver al menu principal");
        scanf("%i", &playAgain);
        if (playAgain == 1)
        {
          goto apuestaInicial;
        }
        else if (playAgain == 2)
    {
      goto MenuPrincipal;
    }
      }
    }
  }

  else if (TenCardOdds2 > 30)
  {
    printf("Las cartas iniciales del dealer fueron %i y %i\n", random3, random4);
    cpu_sum += random3 + random4;
    
    while (cpu_sum < 17)
      {
        puts("Como el total del dealer es menor a 17, el dealer tiene que pedir una carta mas");
        cpu_sum += rand()%10+1;
        printf("El nuevo total del dealer es %i", cpu_sum);
      }
    
    if (cpu_sum > 21)
    {
      puts("El dealer se paso de 21, GANASTE!!");
      fichas += apuesta;
      printf("Tu nuevo total de fichas es %i\n", fichas);
      puts("Presiona 1 para pedir otra mano de cartas. \tPresiona 2 para volver al menu principal");
      scanf("%i", &playAgain);
      if (playAgain == 1)
      {
        goto apuestaInicial;
      }
      else if (playAgain == 2)
    {
      goto MenuPrincipal;
    }
      }
    }

    else if (cpu_sum <= 21)
    {
      printf("  La mano final del dealer es %i\n", cpu_sum);
      if (player_sum > cpu_sum)
      {
        puts("Tu mano es mayor, Ganaste!!");
        fichas += apuesta;
        printf("Tu nuevo total de fichas es %i", fichas);
        puts("Presiona 1 para jugar otra vez. \tPresiona 2 para volver al menu principal");
        while (playAgain != 1 && playAgain != 2)
    {
      scanf("%i", &playAgain);
      if (playAgain == 1)
      {
        goto apuestaInicial;
      }
      else if (playAgain == 2)
    {
      goto MenuPrincipal;
    }
      }
        }
      else if (player_sum < cpu_sum)
      {
        puts("Tu mano es menor, Perdiste!!");
        fichas -= apuesta;
        printf("Tu nuevo total de fichas es %i", fichas);
       
        puts("Presiona 1 para jugar otra vez. \tPresiona 2 para volver al menu principal");
        while (playAgain != 1 && playAgain != 2)
    {
      scanf("%i", &playAgain);
      if (playAgain == 1)
      {
        goto apuestaInicial;
      }
      else if (playAgain == 2)
    {
      goto MenuPrincipal;
    }
      }
        }
      else
      {
        puts("Es un empate, no pierdes ni ganas fichas");
        puts("Presiona 1 para pedir jugar otra vez. \tPresiona 2 para volver al menu principal");
        while (playAgain != 1 && playAgain != 2)
    {
      scanf("%i", &playAgain);
      if (playAgain == 1)
      {
        goto apuestaInicial;
      }
      else if (playAgain == 2)
    {
      goto MenuPrincipal;
    }
      }
    }
  }
    break;
      
    default:
      break;
      
      }
  return 0;
}
  }