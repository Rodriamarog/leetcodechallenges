#ifndef _LIBRERIA_H_
#define _LIBRERIA_H_
extern char piedra(void);
extern char papel(void);
extern char tijera(void);
extern char pistola(void);
extern char universo(void);
extern char saturno(void);
#endif