#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "libreria.h"

int main(void){
  //Centinela para salir del while y volver al menu principal cuando se queda sin fichas en blackjack
  char centinela = 'x';
  //Seleccion del juego para el switch / case del menu principal
  int juego = 0;
  //Variable para checar si el jugador quiere volver a jugar el mismo juego o no
  int seguir = 0;
  //Variables para el juego de planetas
  int peso = 0;
  int planeta = 0;
  //Variables para el juego de trivia
  int score = 0;
  int respuesta = 0;
  //Variables para el juego de blackjack - Fichas se inicia en 1000
  int fichas = 1000;
  //Estas variables van llevando la suma de las cartas del jugador y el cpu en blackjack
  int player_sum = 0;
  int cpu_sum = 0;

  // Variables Black Jack
  // Probabilidades de Blackjack y carta 10 para Jugador
  int TenCardOdds = rand() % 100 + 1;
  int BlackjackOdds = rand() % 100 + 1;

  // Probabilidades de Blackjack y carta 10 para Dealer
  int TenCardOdds2 = rand() % 100 + 1;
  int BlackjackOdds2 = rand() % 100 + 1;

  // Cartas random menores a 10 para Jugador
  int random1 = rand() % 10 + 1;
  int random2 = rand() % 10 + 1;

  // Cartas random menores a 10 para Dealer
  int random3 = rand() % 10 + 1;
  int random4 = rand() % 10 + 1;

  //'Apuesta' para saber cuantas fichas quiere apostar. 'otraCarta' es para saber si quiere pedir otra carta el jugador o no. 'playAgain' es para saber si quiere volver a jugar blackjack o no. 
  int apuesta = 0;
  int otraCarta = 0;
  int playAgain = 0;

  srand(time(NULL));
  
//Tag 'MenuPrincipal' es importante. Todos los juegos dentro del programa mandan a este tag cuando se ingresa el centinela para salir.
MenuPrincipal:
  fichas = 1000;
  system("clear");
  // Menu principal//
  printf("\t\t\t\t\t\t  >>> MENU PRINCIPAL <<<\n\n\n");
  puts("1. Piedra Papel o Tijera\n");
  puts("2. Ruleta Rusa\n");
  puts("3. Calculadora de peso en Planetas\n");
  puts("4. Juego de Trivia\n");
  puts("5. Blackjack\n");
  printf("Escribe el numero del juego");
printf("\n\n\nNOTA IMPORTANTE: Favor de no ingresar una letra / caracter cuando se pide que se ingrese un numero porque no va a funcionar. Esto es por diseño, es a proposito, es un feature no es un bug!");
  printf("\n\n>>> ");
  scanf("%d", &juego);
  system("clear");
  switch (juego) {
  //Piedra papel o tijera
  case 1:
  inicioPPT:
  system("clear");
    srand(time(NULL));
    int random = rand();
    int selecc_cpu = random % 3 + 1;
    int selecc_jugador = 0;

    // Pedimos la seleccion del jugador
    printf("Elige piedra papel o tijeras con los siguientes numeros:\n\n");
    puts("1.Piedra  2.Papel  3.Tijeras\n\n (Tambien puedes escribir -1 para salirte)");
    puts(">>>");
    scanf("%i", &selecc_jugador);
    puts(" ");

    // Si no nos da un numero valido, volvemos al inicio con goto
    if (selecc_jugador != 1 && selecc_jugador != 2 && selecc_jugador != 3 && selecc_jugador != -1) {
      system("clear");
      puts("No diste un numero valido, los numeros validos solo son 1, 2 y 3, "
           "vuelve a intentarlo.\n");
      goto inicioPPT;
    }

    // Imprime la seleccion del CPU
    if (selecc_cpu == 1) {
      puts("La computadora selecciono Piedra");
      piedra();
    } else if (selecc_cpu == 2) {
      puts("La computadora selecciono Papel");
      papel();
    } else if (selecc_cpu == 3) {
      puts("La computadora selecciono Tijeras\n");
      tijera();
    }

    // Imprimie la seleccion del Jugador
    if (selecc_jugador == -1)
      goto MenuPrincipal;
    else if (selecc_jugador == 1) {
      puts("\nTu seleccionaste Piedra\n");
      piedra();
    } else if (selecc_jugador == 2) {
      puts("\nTu seleccionaste Papel\n");
      papel();
    } else if (selecc_jugador == 3) {
      puts("\nTu seleccionaste Tijeras\n");
      tijera();
    }

    // Lo que sucede si la compu y el jugador eligen lo mismo
    if (selecc_cpu == selecc_jugador) {
      puts("\nEs un empate!");
    }

    // Los casos posibles cuando la computadora elige piedra
    else if (selecc_cpu == 1 && selecc_jugador == 2) {
      puts("\nGanaste!");
    } else if (selecc_cpu == 1 && selecc_jugador == 3) {
      puts("\nGano la computadora!");
    }

    // Los casos posibles cuando la computadora elige papel
    else if (selecc_cpu == 2 && selecc_jugador == 1) {
      puts("\nGano la computadora!");
    } else if (selecc_cpu == 2 && selecc_jugador == 3) {
      puts("\nGanaste!");
    }

    // Los casos posibles cuando la computadora elige Tijeras
    else if (selecc_cpu == 3 && selecc_jugador == 1) {
      puts("\nGanaste!");
    } else if (selecc_cpu == 3 && selecc_jugador == 2) {
      puts("\nGano la computadora!");
    }
  ifPPT:
    puts("\nPara jugar otra vez, presiona el 1\n\nPara ir al menu principal, "
         "presiona el 2");
    scanf("%i", &seguir);

    if (seguir == 1)
      goto inicioPPT;
    else if (seguir == 2)
      goto MenuPrincipal;
    else {
      system("clear");
      puts("Input no valido");
      goto ifPPT;
    }
    break;

  //Ruleta rusa
  case 2:
  inicioRULETA:
    system("clear");
    //Generador de numeros al azar
    srand(time(NULL));
    int random2 = rand();

    //Arreglos que representan el numero de bala, los jugadores, y la eleccion de bala por los jugadores.
    int numeros[6] = {1, 2, 3, 4, 5, 6};
    int jugadores[6] = {1, 2, 3, 4, 5, 6};
    int jug_num[6] = {0, 0, 0, 0, 0, 0};

    //For loop para pedir a cada jugador que elijan una bala
    for (int i = 0; i <= 5; i++) {
      system("clear");
      printf("Jugador #%i, elige un numero del 1-6. \n\n Los numeros "
             "disponibles son \n",
             jugadores[i]);
      for (int j = 0; j < 6; j++) {
        if (numeros[j] != jug_num[0] && numeros[j] != jug_num[1] &&
            numeros[j] != jug_num[2] && numeros[j] != jug_num[3] &&
            numeros[j] != jug_num[4] && numeros[j] != jug_num[5]) {
          printf("%i ", numeros[j]);
        }
      }
      printf("\n\n(Si el jugador #%i no quiere jugar, puede elegir un numero "
             "fuera de la lista\n\n (Tambien pueden escribir -1 en cualquier "
             "momento para salir del juego)\n>>> ",
             jugadores[i]);
      scanf("%i", &jug_num[i]);
      if (jug_num[i] == -1)
        goto MenuPrincipal;
      
    }
    //RNG del 1-6, se imprime el numero generado
    int bala = random2 % 6 + 1;
    printf("\nLa bala que disparo fue la {%i}\n", bala);
    pistola();
    //for para comparar la bala 'disparada' con la lista de eleccion de bala por los jugadores. El jugador que elige la bala disparada pierde.
    for (int k = 0; k <= 5; k++) {
      if (jug_num[k] == bala) {
        printf("\nEl jugador que perdio fue el %i\n", k + 1);
      }
    }
    puts("\nPara jugar otra vez, presiona el 1\n\nPara ir al menu principal, "
         "presiona el 2\n");
  ifRULETA:
    scanf("%i", &seguir);
    if (seguir == 1)
      goto inicioRULETA;
    else if (seguir == 2)
      goto MenuPrincipal;
    else {
      puts("Input no valido");
      goto ifRULETA;
    }

    break;
  //Planetas
  case 3:
  inicioPlanetas:
    system("clear");
    //Pedimos el peso (solo valor valido)
    printf("Dime tu peso en kg: \n\n(Tambin puedes escribir -1 para salirte)\n\n>>> ");
    ScanPeso:
    scanf("%i", &peso);
    if (peso == -1)
      goto MenuPrincipal;
    else if (peso <= 0)
    {
      printf("No puedes tener un peso negativo o de 0, dame un valor valido\n>>> ");
      goto ScanPeso;
    }
    //Se pide que se elija un planeta
    inicioPlanetas2:
    system("clear");
    puts("Elige un planeta para calcluar tu peso en kilogramos: ");
    puts("1. Luna\n2. Mercurio\n3. Venus\n4. Marte\n5. Jupiter\n6. Saturno\n7. "
         "Urano\n8. Neptuno\n\n(Tambien puedes escribir -1 para salirte)\n");
    universo();
    scanf("%i", &planeta);
    //Inicio de switch / case dependiendo del planeta que se elige
    switch (planeta) {
    case 1:
      printf("Tu peso en la luna es de %.2f kg", peso * 0.165);
      puts("\t🌚");
      goto ifPlanetas;
      break;
    case 2:
      printf("Tu peso en Mercurio es de %.2f kg", peso * 0.38);
      goto ifPlanetas;
      break;
    case 3:
      printf("Tu peso en Venus es de %.2f kg", peso * 0.91);
      goto ifPlanetas;
      break;
    case 4:
      printf("Tu peso en Marte es de %.2f kg", peso * 0.38);
      goto ifPlanetas;
      break;
    case 5:
      printf("Tu peso en Jupiter es de %.2f kg", peso * 2.479);
      goto ifPlanetas;
      break;
    case 6:
      printf("Tu peso en Saturno es de %.2f kg\n\n", peso * 1.08);
      saturno();
      goto ifPlanetas;
      break;
    case 7:
      printf("Tu peso en Urano es de %.2f kg", peso * 0.86);
      goto ifPlanetas;
      break;
    case 8:
      printf("Tu peso en Neptuno es de %.2f kg", peso * 1.1);
      goto ifPlanetas;
      break;
    case -1:
      goto MenuPrincipal;
    default:
      goto inicioPlanetas2;
      break;
      
    //Preguntamos si quiere volver a jugar o ir al menu principal
    ifPlanetas:
      puts("\n\nQuieres explorar otro planeta o volver al menu principal?\n1) "
           "Explorar otro planeta\n2) Menú Principal");
      scanf("%i", &seguir);
      if (seguir == 1)
        goto inicioPlanetas2;
      else if (seguir == 2)
        goto MenuPrincipal;
      else {
        puts("Valor invalido");
        goto ifPlanetas;
      }
    }
    break;

  case 4:
  inicioTrivia:
  score = 0;
    system("clear");
    printf("Bienvenido a el quiz mas importante de tu vida!!\nVan a ser 10 "
           "preguntas, y 3 respuestas posibles por pregunta. \nTu puntuacion "
           "sera del 0-10. Elige la respuesta correcta. Suerte!\n\n(Nota: En cualquier momento puedes responer con '-1' para salirte)\n\n");
    puts("(╭ರ_ ⊙ )\n");
    printf("Pregunta 1.\tQuien era el Dios Romano de la guerra?\n1) Ares\n2) "
           "Jupiter\n3) Marte\n"); // Marte
    scanf("%i", &respuesta);
    system("clear");
    if (respuesta == -1)
      goto MenuPrincipal;
    else if (respuesta == 3) {
      printf("Respuesta correcta!\n\n");
      score++;
    } else {
      puts("Respuesta incorrecta\n\n");
    }

    printf("Pregunta 2. \n Quien escribio la Odisea?\n1) Aristoteles \n2) "
           "Platon \n3) Homero \n");
    scanf("%i", &respuesta);
    system("clear");
    if (respuesta == -1)
      goto MenuPrincipal;
    else if (respuesta == 3) {
      puts("Respuesta correcta!\n\n");
      score++;
    } else {
      puts("Respuesta incorrecta\n\n");
    }
    printf("Pregunta 3. \n Cuantos huesos tiene el cuerpo humano adulto?\n1) "
           "207 \n2) 300 \n3) 206\n ");
    scanf("%i", &respuesta);
    system("clear");
    if (respuesta == -1)
      goto MenuPrincipal;
    else if (respuesta == 3) {
      puts("Respuesta correcta!\n\n");
      score++;
    } else {
      puts("Respuesta incorrecta\n\n");
    }
    printf("Pregunta 4. \n Cual es el animal mas rapido del mundo?\n1) Jaguar "
           "\n2) Guepardo \n3) Cheetah\n ");
    scanf("%i", &respuesta);
    system("clear");
    if (respuesta == -1)
      goto MenuPrincipal;
    else if (respuesta == 2) {
      puts("Respuesta correcta!\n\n");
      score++;
    } else {
      puts("Respuesta incorrecta\n\n");
    }

    printf("Pregunta 5 \n Quien pinto la ultima cena?\n1) Leonardo DaVinci "
           "\n2) Leonardo Dicaprio \n3) Michelangelo\n ");
    scanf("%i", &respuesta);
    system("clear");
    if (respuesta == -1)
      goto MenuPrincipal;
    else if (respuesta == 1) {
      puts("Respuesta correcta!\n\n");
      score++;
    } else {
      puts("Respuesta incorrecta\n\n");
    }
    printf("Pregunta 6. \n Cual es el libro mas vendido de la historia?\n1) "
           "Romeo y Julieta \n2) La Biblia \n3) Don Quijote de la Mancha\n ");
    scanf("%i", &respuesta);
    system("clear");
    if (respuesta == -1)
      goto MenuPrincipal;
    else if (respuesta == 2) {
      puts("Respuesta correcta!\n\n");
      score++;
    } else {
      puts("Respuesta incorrecta\n\n");
    }

    printf("Pregunta 7. \n Cuantos elemntos hay en la tabla periodica?\n1) 120 "
           "\n2) 118 \n3) 115\n ");
    scanf("%i", &respuesta);
    system("clear");
    if (respuesta == -1)
      goto MenuPrincipal;
    else if (respuesta == 2) {
      puts("Respuesta correcta!\n\n");
      score++;
    } else {
      puts("Respuesta incorrecta\n\n");
    }

    printf("Pregunta 8. \n En que pais se uso la primer bomba "
           "atomica?\n1) Alemania \n2) Rusia \n3) Japon \n");
    scanf("%i", &respuesta);
    system("clear");
    if (respuesta == -1)
      goto MenuPrincipal;
    else if (respuesta == 3) {
      puts("Respuesta correcta!\n\n");
      score++;
    } else {
      puts("Respuesta incorrecta\n\n");
    }

    printf("Pregunta 9. \n Cuantas veces ha estado el hombre en la luna?\n1) 1 "
           "vez \n2) 6 veces \n3) 3 veces \n");
    scanf("%i", &respuesta);
    system("clear");
    if (respuesta == -1)
      goto MenuPrincipal;
    else if (respuesta == 2) {
      puts("Respuesta correcta!\n\n");
      score++;
    } else {
      puts("Respuesta incorrecta\n\n");
    }
    printf("Pregunta 10. \n Cual es el rio mas largo del planeta?\n1) El "
           "Amazonas \n2) El Nilo \n3) El Bravo \n");
    scanf("%i", &respuesta);
    system("clear");
    if (respuesta == -1)
      goto MenuPrincipal;
    else if (respuesta == 2) {
      puts("Respuesta correcta!\n\n");
      score++;
    } else {
      puts("Respuesta incorrecta\n\n");
    }
    printf("Tu puntuacion final es de %i\n", score);
  ifTrivia:
    puts("Quieres jugar otra vez a Trivia o ir al menu principal?\n1) Jugar "
         "Otra Vez\n2) Menu Principal");
    scanf("%i", &seguir);
    if (seguir == 1)
      goto inicioTrivia;
    else if (seguir == 2)
      goto MenuPrincipal;
    else {
      puts("Valor invalido");
      goto ifTrivia;
    }

    break;

  case 5:
    system("clear");
    blackjack();                      
    srand(time(0));
    // Centinela
    char centinel = ' ';

  // Aqui se reinicia todo excepto las fichas
  apuestaInicial:
  
    if (fichas <= 0) {
      puts("\nTe quedaste sin fichas, no puedes seguir jugando!");
      puts("\nEste programa es irrompible.\n\nEscribe el # para volver al menu "
           "principal");
      while (centinel != '#') {
        scanf("%c", &centinel);
      }
      goto MenuPrincipal;
    }

    system("clear");

    player_sum = 0;
    cpu_sum = 0;
    TenCardOdds = rand() % 100 + 1;
    BlackjackOdds = rand() % 100 + 1;
    random1 = rand() % 10 + 1;
    random2 = rand() % 10 + 1;
    TenCardOdds2 = rand() % 100 + 1;
    BlackjackOdds2 = rand() % 100 + 1;
    random3 = rand() % 10 + 1;
    random4 = rand() % 10 + 1;
    
    // Candado si usuario intenta apostar mas de las fichas que tiene
    blackjack();
    printf("\nBienvenido a Blackjack! \n\nTienes %i fichas, cuantas quieres "
           "apostar? (Si quieres salir, escribe -1)\n>>> ",
           fichas);
    scanf("%i", &apuesta);
    if (apuesta > fichas) {
      puts("\nNo tienes suficientes fichas y este programa es IRROMPIBLE, vuelve "
           "a intentarlo.\n");
      goto apuestaInicial;
    }

    else if (apuesta == -1)
      goto MenuPrincipal;

    else if (apuesta <= 0) {
      puts("No puedes apostar cero o un numero negativo de fichas porque este "
           "programa no tiene bugs y no se rompe! De vuelta al inicio.\n");
      goto apuestaInicial;
    }
    system("clear");

    // Probabilidades de Blackjack
    if (BlackjackOdds <= 8) {
      puts("\nTus cartas iniciales fueron 10 y A, FELICIDADES CONSEGUISTE "
           "BLACKJACK!!!\n");
      fichas += apuesta;
      printf("\nTu nuevo total de fichas es %i\n", fichas);
      goto BlackjackPlayAgain;
    }

    // Probabilidades de obtener carta con valor de 10
    else if (TenCardOdds <= 30) {
      printf("\nTus cartas iniciales fueron %i y %i\n", 10, random1);
      player_sum += 10 + random1;
      while (player_sum <= 21) {
        printf("\nLa suma es %i\n", player_sum);

      OtraCarta1:
        printf("\nQuieres otra carta? Escribe 1 para Sí y 2 para No\n(Tambien "
               "puedes escribir el 99 para salirte)\n>>> ");
        scanf("%i", &otraCarta);

        if (otraCarta != 1 && otraCarta != 2 && otraCarta != 99) {
          puts("No me diste un numero valido, es 1 para Si y 2 para "
               "No.\n(Tambien puedes escribir 99 para salirte).\nVuelve a "
               "intentarlo.");
          goto OtraCarta1;
        }

        else if (otraCarta == 1) {
          player_sum += rand() % 10 + 1;
        }

        else if (otraCarta == 99) {
          goto MenuPrincipal;
        }

        else {
          break;
        }
      }

      if (player_sum <= 21) {
        system("clear");
        printf(
            "Tu mano final es %i, veamos que consigue el Dealer, suerte!\n\n",
            player_sum);
      }

      else {
        printf("Tu mano final es %i\n Como te pasaste de 21, pierdes tu "
               "apuesta!\n",
               player_sum);
        fichas -= apuesta;
        printf("\nTu nuevo total de fichas es %i\n", fichas);
        goto BlackjackPlayAgain;
      }
    }

    // Secuencia normal si no hubo Blackjack ni carta con valor 10
    else {
      printf("\nTus cartas iniciales fueron %i y %i\n", random1, random2);
      player_sum += random1 + random2;
      while (player_sum <= 21) {
        printf("\nLa suma es %i\n", player_sum);

      OtraCarta2:
        printf("\nQuieres otra carta? Escribe 1 para Sí y 2 para No\n(Tambien "
               "puedes escribir 99 para salirte)\n>>> ");
        scanf("%i", &otraCarta);

        if (otraCarta != 1 && otraCarta != 2 && otraCarta != 99) {
          puts("No me diste un numero valido, es 1 para Si y 2 para "
               "No\n\n(Tambien puedes escribir el 99 para salirte)\n\n Vuelve "
               "a intentarlo.\n ");
          goto OtraCarta2;
        }

        else if (otraCarta == 1) {
          player_sum += rand() % 10 + 1;
        }

        else if (otraCarta == 99) {
          goto MenuPrincipal;
        }

        else {
          break;
        }
      }

      if (player_sum <= 21) {
        system("clear");
        printf(
            "\nTu mano final es %i, veamos que consigue el Dealer, suerte!\n\n",
            player_sum);
      }

      else {
        printf("\nTu mano final es %i, te pasaste de 21, pierdes tu apuesta!\n",
               player_sum);
        fichas -= apuesta;
        printf("\nTu nuevo total de fichas es %i\n", fichas);
        goto BlackjackPlayAgain;
      }
    }

    // Secuencia si el jugador no pierde. Se inicia la mano del Dealer
    puts("Comenzamos con el turno del Dealer\n");

    if (BlackjackOdds2 <= 8) {
      puts("Las cartas fueron 10 y A. El dealer obtuvo Blackjack!! Pierdes tu "
           "apuesta");
      fichas -= apuesta;
      printf("\nTu nuevo total de fichas es %i\n", fichas);
      goto BlackjackPlayAgain;
    }

    else if (TenCardOdds2 <= 30) {
      printf("Las cartas iniciales del dealer fueron %i y %i\n", 10, random3);
      cpu_sum += 10 + random3;

      while (cpu_sum < 17) {
        puts("\nComo el total del dealer es menor a 17, el dealer tiene que "
             "pedir una carta mas\n");
        cpu_sum += rand() % 10 + 1;
        printf("El nuevo total del dealer es %i\n", cpu_sum);
      }

      if (cpu_sum > 21) {
        puts("\nEl dealer se paso de 21, GANASTE!!\n");
        fichas += apuesta;
        printf("Tu nuevo total de fichas es %i\n", fichas);
        goto BlackjackPlayAgain;
      }

      else if (cpu_sum <= 21) {
        printf("\nLa mano final del dealer es %i\n", cpu_sum);
        if (player_sum > cpu_sum) {
          puts("\nTu mano es mayor, Ganaste!!");
          fichas += apuesta;
          printf("\nTu nuevo total de fichas es %i", fichas);
          goto BlackjackPlayAgain;
        }

        else if (player_sum < cpu_sum) {
          puts("\nTu mano es menor, Perdiste!!\n");
          fichas -= apuesta;
          printf("\nTu nuevo total de fichas es %i", fichas);
          goto BlackjackPlayAgain;
        }

        else {
          puts("\nEs un empate, no pierdes ni ganas fichas\n");
          goto BlackjackPlayAgain;
        }
      }
    }

    else if (TenCardOdds2 > 30) {
      printf("Las cartas iniciales del dealer fueron %i y %i\n", random3,
             random4);
      cpu_sum += random3 + random4;

      while (cpu_sum < 17) {
        puts("\nComo el total del dealer es menor a 17, el dealer tiene que "
             "pedir una carta mas\n");
        cpu_sum += rand() % 10 + 1;
        printf("El nuevo total del dealer es %i\n", cpu_sum);
      }

      if (cpu_sum > 21) {
        puts("\nEl dealer se paso de 21, GANASTE!!");
        fichas += apuesta;
        printf("Tu nuevo total de fichas es %i\n", fichas);
        goto BlackjackPlayAgain;
      }

      else if (cpu_sum <= 21) {
        printf("\nLa mano final del dealer es %i\n", cpu_sum);
        if (player_sum > cpu_sum) {
          puts("\nTu mano es mayor, Ganaste!!\n");
          fichas += apuesta;
          printf("Tu nuevo total de fichas es %i\n", fichas);
          goto BlackjackPlayAgain;
        }

        else if (player_sum < cpu_sum) {
          puts("\nTu mano es menor, Perdiste!!\n");
          fichas -= apuesta;
          printf("Tu nuevo total de fichas es %i\n", fichas);
          goto BlackjackPlayAgain;
        }

        else {
          puts("Es un empate, no pierdes ni ganas fichas");
          goto BlackjackPlayAgain;
        }
      }
    }

  BlackjackPlayAgain:
    printf("\n\nQuieres jugar de nuevo? Escribe 1 para Si o 2 para No\n>>> ");
    scanf("%i", &playAgain);
    if (playAgain == 1)
      goto apuestaInicial;
    else if (playAgain == 2)
      goto MenuPrincipal;
    else {
      puts("Respuesta no valida. \n\nEste programa es irrompible. Intentalo de "
           "nuevo.");
      goto BlackjackPlayAgain;
    }
    case 253:
    
    default:
      goto MenuPrincipal;
      break;
      
    return 0;
  } 
}
